<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">




	<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
		<meta name="author" content="PRACAS.NET"/>	
		<meta name="description" content="Neuro Hospital is the best hospital in Biratnagar providing best healthcare services in Nepal"/>
		<meta name="keywords" content="neuro hospital, biratnagar hospital, hospital in biratnagar, biratnagar neuro hospital, neuro hospital in nepal, biratnagar hospital">	
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
				
  		<!-- SITE TITLE -->
		  <title>Neuro Hospital - Biratnagar | Hospital in Nepal</title>
							
		<!-- Favicon code starts here  -->


		<link rel="apple-touch-icon" sizes="180x180" href="https://pracas.net/favicon/apple-touch-icon.png">
		<link rel="icon" type="image/png" sizes="32x32" href="https://pracas.net/favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="https://pracas.net/favicon/favicon-16x16.png">
		<link rel="manifest" href="https://pracas.net/favicon/site.webmanifest">
		<link rel="mask-icon" href="https://pracas.net/favicon/safari-pinned-tab.svg" color="#5bbad5">
		<link rel="shortcut icon" href="https://pracas.net/favicon/favicon.ico">
		<meta name="msapplication-TileColor" content="#da532c">
		<meta name="msapplication-config" content="https://pracas.net/favicon/browserconfig.xml">
		<meta name="theme-color" content="#ffffff">
	  
	  
	  
		<!-- Favicon code ends here  -->


		<!-- GOOGLE FONTS -->
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet"> 	
		<link href="https://fonts.googleapis.com/css?family=Lato:400,700,900" rel="stylesheet"> 

		<!-- BOOTSTRAP CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
				
		<!-- FONT ICONS -->
		<link href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" rel="stylesheet" crossorigin="anonymous">		
		<link href="css/flaticon.css" rel="stylesheet">

		<!-- PLUGINS STYLESHEET -->
		<link href="css/menu.css" rel="stylesheet">	
		<link id="effect" href="css/dropdown-effects/fade-down.css" media="all" rel="stylesheet">
		<link href="css/magnific-popup.css" rel="stylesheet">	
		<link href="css/owl.carousel.min.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css" rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/jquery.datetimepicker.min.css" rel="stylesheet">
				
		<!-- TEMPLATE CSS -->
		<link href="css/style.css" rel="stylesheet">
		
		<!-- RESPONSIVE CSS -->
		<link href="css/responsive.css" rel="stylesheet"> 
	
	</head>




	<body>




		<!-- PRELOADER SPINNER
		============================================= -->	
		<div id="loader-wrapper">
			<div id="loader"><div class="loader-inner"></div></div>
		</div>




		



		<!-- PAGE CONTENT
		============================================= -->	
		<div id="page" class="page">




			<!-- Place header.php -->
			<?php include("header.php"); ?>




			<!-- BREADCRUMB
			============================================= -->
			<div id="breadcrumb" class="division">
				<div class="container">
					<div class="row">						
						<div class="col">
							<div class=" breadcrumb-holder">

								<!-- Breadcrumb Nav -->
								<nav aria-label="breadcrumb">
								  	<ol class="breadcrumb">
								    	<li class="breadcrumb-item"><a href="demo-1.html">Home</a></li>
								    	<li class="breadcrumb-item active" aria-current="page">Blog</li>
								  	</ol>
								</nav>

								<!-- Title -->
								<h4 class="h4-sm steelblue-color">Blog</h4>

							</div>
						</div>
					</div>  <!-- End row -->	
				</div>	<!-- End container -->		
			</div>	<!-- END BREADCRUMB -->	



			




			<!-- BLOG-1
			============================================= -->
			<section id="blog-1" class="wide-60 blog-section division">				
				<div class="container">


					<!-- SECTION TITLE -->	
					<div class="row">	
						<div class="col-lg-10 offset-lg-1 section-title">	

							<!-- Title 	-->	
							<h3 class="h3-md steelblue-color">Hospital Updates</h3>	

							<!-- Text -->
							<!-- <p>Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero at tempus, 
							   blandit posuere ligula varius congue cursus porta feugiat
							</p> -->
								
						</div>
					</div>






			 		<!-- BLOG POSTS HOLDER -->
				 	<div class="row">


				 		<!-- BLOG POST #1 -->
				 		<div class="col-lg-4">
				 			<div class="blog-post wow fadeInUp" data-wow-delay="0.4s">

				 				<!-- BLOG POST IMAGE -->
					 			<div class="blog-post-img">
									<img class="img-fluid" src="images/updates/1.jpg" alt="blog-post-image" />	
								</div>

				 				<!-- BLOG POST TITLE -->
								<div class="blog-post-txt">

									<!-- Post Title -->
									<h5 class="h5-sm steelblue-color"><a href="#">Causes of depression</a></h5>

									<!-- Post Data -->
									<span>24 September 2023 </span>

									<!-- Post Text -->
									<p>
									   Depression is a complex and multifaceted condition, and its causes can vary from person to person. 
									   It often results..........
									</p><br>
									<a href="https://medium.com/neuro-hospital-biratnagar/causes-of-depression-3e20288cad08"  target="_blank" class="btn btn-tra-grey white-hover">Read More</a>


								</div>

							</div>
				 		</div>	<!-- END  BLOG POST #1 -->


				 		<!-- BLOG POST #2 -->
				 		<div class="col-lg-4">
				 			<div class="blog-post wow fadeInUp" data-wow-delay="0.6s">

				 				<!-- BLOG POST IMAGE -->
					 			<div class="blog-post-img">
									<img class="img-fluid" src="images/updates/2.jpg" alt="blog-post-image" />	
								</div>

				 				<!-- BLOG POST TEXT -->
								<div class="blog-post-txt">

									<!-- Post Title -->
									<h5 class="h5-sm steelblue-color"><a href="#">How to get rid from headache ?</a></h5>

									<!-- Post Data -->
									<span>24 September 2023by </span>

									<!-- Post Text -->
									<p>Headaches can have a wide range of causes, and they can vary in severity and duration. Here are some 
									common reasons..........
									</p><br>
									<a href="https://medium.com/neuro-hospital-biratnagar/how-to-get-rid-from-headache-2de2beb0ec58" target="_blank" class="btn btn-tra-grey white-hover">Read More</a>


								</div>

							</div>
				 		</div>	<!-- END  BLOG POST #2 -->


				 		<!-- BLOG POST #3 -->
				 		<div class="col-lg-4">
				 			<div class="blog-post wow fadeInUp" data-wow-delay="0.8s">

				 				<!-- BLOG POST IMAGE -->
					 			<div class="blog-post-img">
									<img class="img-fluid" src="images/updates/3.jpg" alt="blog-post-image" />	
								</div>

				 				<!-- BLOG POST TEXT -->
								<div class="blog-post-txt">

									<!-- Post Title -->
									<h5 class="h5-sm steelblue-color"><a href="#">Reasons of insomnia</a></h5>

									<!-- Post Data -->
									<span>24 September 2023 </span>

									<!-- Post Text -->
									<p>Insomnia is a common sleep disorder characterized by difficulty falling asleep, staying asleep, 
									or experiencing..........
									</p><br>
									<a href="https://medium.com/neuro-hospital-biratnagar/reasons-of-insomnia-e46bd8894c0f"  target="_blank" class="btn btn-tra-grey white-hover">Read More</a>


								</div>

							</div>
				 		</div>	<!-- END  BLOG POST #3 -->


					</div>	<!-- END BLOG POSTS HOLDER -->





					<div class="row">


						<!-- BLOG POST #4 -->
						<div class="col-lg-4">
							<div class="blog-post wow fadeInUp" data-wow-delay="0.4s">
	
								<!-- BLOG POST IMAGE -->
								<div class="blog-post-img">
								   <img class="img-fluid" src="images/updates/4.jpg" alt="blog-post-image" />	
							   </div>
	
								<!-- BLOG POST TITLE -->
							   <div class="blog-post-txt">
	
								   <!-- Post Title -->
								   <h5 class="h5-sm steelblue-color"><a href="#">What is Alzheimer?</a></h5>
	
								   <!-- Post Data -->
								   <span>24 September 2023 </span>
	
								   <!-- Post Text -->
								   <p>
									Alzheimer’s disease is a progressive and degenerative brain disorder that primarily affects memory, thinking, and..........
								   </p><br>

								   <a href="https://medium.com/neuro-hospital-biratnagar/what-is-alzheimer-baeb87bd6126"  target="_blank" class="btn btn-tra-grey white-hover">Read More</a>

	
							   </div>
	
						   </div>
						</div>	<!-- END  BLOG POST #4 -->


						<!-- BLOG POST #5 -->
						<div class="col-lg-4">
							<div class="blog-post wow fadeInUp" data-wow-delay="0.6s">

								<!-- BLOG POST IMAGE -->
								<div class="blog-post-img">
								   <img class="img-fluid" src="images/updates/5.jpg" alt="blog-post-image" />	
							   </div>

								<!-- BLOG POST TEXT -->
							   <div class="blog-post-txt">

								   <!-- Post Title -->
								   <h5 class="h5-sm steelblue-color"><a href="#">What is mindfulness ?</a></h5>

								   <!-- Post Data -->
								   <span>24 September 2023 <span> </span></span>

								   <!-- Post Text -->
								   <p>Mindfulness is a mental practice and state of awareness characterized by paying deliberate 
									and non-judgmental..........
								   </p> <br>

								   <a href="https://medium.com/neuro-hospital-biratnagar/what-is-mindfulness-44d8026d106f" target="_blank" class="btn btn-tra-grey white-hover">Read More</a>


							   </div>

						   </div>
						</div>	<!-- END  BLOG POST #5 -->


						<!-- BLOG POST #6 -->
						<div class="col-lg-4">
							<div class="blog-post wow fadeInUp" data-wow-delay="0.8s">

								<!-- BLOG POST IMAGE -->
								<div class="blog-post-img">
								   <img class="img-fluid" src="images/updates/6.jpg" alt="blog-post-image" />	
							   </div>

								<!-- BLOG POST TEXT -->
							   <div class="blog-post-txt">

								   <!-- Post Title -->
								   <h5 class="h5-sm steelblue-color"><a href="#">How to change bad habits?</a></h5>

								   <!-- Post Data -->
								   <span>24 September 2023  </span>

								   <!-- Post Text -->
								   <p>Changing bad habits can be challenging, but it’s entirely possible with the right 
									trategies and determination..........
								   </p> <br>

								   <a href="https://medium.com/neuro-hospital-biratnagar/how-to-change-bad-habits-44d54f63638e" target="_blank" class="btn btn-tra-grey white-hover">Read More</a>


							   </div>

						   </div>
						</div>	<!-- END  BLOG POST # -->


				   </div>
				   	<!-- END BLOG POSTS HOLDER -->



			

				   <div class="row">


					<!-- BLOG POST #7 -->
					<div class="col-lg-4">
						<div class="blog-post wow fadeInUp" data-wow-delay="0.4s">

							<!-- BLOG POST IMAGE -->
							<div class="blog-post-img">
							   <img class="img-fluid" src="images/updates/7.jpg" alt="blog-post-image" />	
						   </div>

							<!-- BLOG POST TITLE -->
						   <div class="blog-post-txt">

							   <!-- Post Title -->
							   <h5 class="h5-sm steelblue-color"><a href="#">What is cardio arrest ?</a></h5>

							   <!-- Post Data -->
							   <span>24 September 2023 </span>

							   <!-- Post Text -->
							   <p>
								Cardiac arrest, often referred to as sudden cardiac arrest (SCA), is a medical emergency in which the heart ..........
							   </p> <br>
							   <a href="https://medium.com/neuro-hospital-biratnagar/what-is-cardio-arrest-1db194b33496" target="_blank" class="btn btn-tra-grey white-hover">Read More</a>


						   </div>

					   </div>
					</div>	<!-- END  BLOG POST #7 -->


					<!-- BLOG POST #8 -->
					<div class="col-lg-4">
						<div class="blog-post wow fadeInUp" data-wow-delay="0.6s">

							<!-- BLOG POST IMAGE -->
							<div class="blog-post-img">
							   <img class="img-fluid" src="images/updates/8.jpg" alt="blog-post-image" />	
						   </div>

							<!-- BLOG POST TEXT -->
						   <div class="blog-post-txt">

							   <!-- Post Title -->
							   <h5 class="h5-sm steelblue-color"><a href="#">How to avoid heart attack ?</a></h5>

							   <!-- Post Data -->
							   <span>24 September 2023</span>

							   <!-- Post Text -->
							   <p>A heart attack, or myocardial infarction, is a medical emergency that occurs when the blood flow to the heart is blocked, causing..........
							   </p> <br>
							   <a href="https://medium.com/neuro-hospital-biratnagar/how-to-avoid-heart-attack-58c5af473b22" target="_blank" class="btn btn-tra-grey white-hover">Read More</a>


						   </div>

					   </div>
					</div>	<!-- END  BLOG POST #8 -->


					<!-- BLOG POST #9 -->
					<div class="col-lg-4">
						<div class="blog-post wow fadeInUp" data-wow-delay="0.8s">

							<!-- BLOG POST IMAGE -->
							<div class="blog-post-img">
							   <img class="img-fluid" src="images/updates/9.jpg" alt="blog-post-image" />	
						   </div>

							<!-- BLOG POST TEXT -->
						   <div class="blog-post-txt">

							   <!-- Post Title -->
							   <h5 class="h5-sm steelblue-color"><a href="#">Symptoms of Narcolepsy</a></h5>

							   <!-- Post Data -->
							   <span>12 September 2023 </span>

							   <!-- Post Text -->
							   <p>Narcolepsy is a chronic neurological disorder characterized by disturbances in sleep patterns and the regulation of wakefulness..........
							   </p> <br>
							   <a href="https://medium.com/neuro-hospital-biratnagar/symptoms-of-narcolepsy-a9d14e4c7abd" class="btn btn-tra-grey white-hover" target="_blank" >Read More</a>


						   </div>

					   </div>
					</div>	<!-- END  BLOG POST #9 -->


			   </div>	<!-- END BLOG POSTS HOLDER -->







				</div>	   <!-- End container -->		
			</section>	<!-- END BLOG-1 -->




		



						<!-- place footer.php -->
						<?php include("footer.php"); ?>




		</div>	<!-- END PAGE CONTENT -->



		<!-- EXTERNAL SCRIPTS
		============================================= -->	
		<script src="js/jquery-3.3.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>	
		<script src="js/modernizr.custom.js"></script>
		<script src="js/jquery.easing.js"></script>
		<script src="js/jquery.appear.js"></script>
		<script src="js/jquery.stellar.min.js"></script>	
		<script src="js/menu.js"></script>
		<script src="js/sticky.js"></script>
		<script src="js/jquery.scrollto.js"></script>
		<script src="js/materialize.js"></script>	
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/jquery.magnific-popup.min.js"></script>	
		<script src="js/imagesloaded.pkgd.min.js"></script>
		<script src="js/isotope.pkgd.min.js"></script>
		<script src="js/hero-form.js"></script>
		<script src="js/contact-form.js"></script>
		<script src="js/comment-form.js"></script>
		<script src="js/appointment-form.js"></script>
		<script src="js/jquery.datetimepicker.full.js"></script>		
		<script src="js/jquery.validate.min.js"></script>	
		<script src="js/jquery.ajaxchimp.min.js"></script>
		<script src="js/wow.js"></script>	
	
		<!-- Custom Script -->		
		<script src="js/custom.js"></script>

		<script> 
			new WOW().init();
		</script>

		<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
		<!-- [if lt IE 9]>
			<script src="js/html5shiv.js" type="text/javascript"></script>
			<script src="js/respond.min.js" type="text/javascript"></script>
		<![endif] -->

		<!-- Google Analytics: Change UA-XXXXX-X to be your site's ID. Go to http://www.google.com/analytics/ for more information. -->	
		<!--
		<script>
			window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
			ga('create', 'UA-XXXXX-Y', 'auto');
			ga('send', 'pageview');
		</script>
		<script async src='https://www.google-analytics.com/analytics.js'></script>
		-->
		<!-- End Google Analytics -->

		<script src="js/changer.js"></script>
		<script defer src="js/styleswitch.js"></script>	
		

	</body>


</html>	